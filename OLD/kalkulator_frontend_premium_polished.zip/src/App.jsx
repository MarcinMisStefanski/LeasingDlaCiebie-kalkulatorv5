
import React, { useState, useEffect } from 'react'

const RRSO = parseFloat(import.meta.env.VITE_RRSO) || 8.5
const okresy = [24, 35, 47, 59]
const rules = {
  24: [18, 60],
  35: [1, 50],
  47: [1, 40],
  59: [1, 30],
}

export default function App() {
  const [price, setPrice] = useState(220000)
  const [initialAmount, setInitialAmount] = useState(40000)
  const [okresIdx, setOkresIdx] = useState(1)
  const months = okresy[okresIdx]
  const [buyoutAmount, setBuyoutAmount] = useState(20000)
  const [warning, setWarning] = useState("")

  const initialPercent = (initialAmount / price) * 100
  const buyoutPercent = (buyoutAmount / price) * 100
  const [minBuyout, maxBuyout] = rules[months]

  useEffect(() => {
    if (buyoutPercent < minBuyout || buyoutPercent > maxBuyout) {
      setWarning(`⚠️ Wykup dla ${months} mies. musi być w zakresie ${minBuyout}–${maxBuyout}%`)
    } else {
      setWarning("")
    }
  }, [buyoutAmount, price, months])

  const monthlyRate = Math.pow(1 + RRSO / 100, 1 / 12) - 1
  const financedAmount = price - initialAmount - buyoutAmount
  const buyoutInterest = buyoutPercent > 1 ? buyoutAmount * monthlyRate * months : 0
  const totalFinanced = financedAmount + buyoutInterest

  const leaseInstallment = totalFinanced * (monthlyRate * Math.pow(1 + monthlyRate, months)) /
    (Math.pow(1 + monthlyRate, months) - 1)

  const totalCost = leaseInstallment * months + initialAmount + buyoutAmount
  const costPercent = (totalCost / price) * 100

  const formatPLN = val => val.toLocaleString("pl-PL", { style: "currency", currency: "PLN" })

  return (
    <div className="container">
      <div className="topbar">
        <img src="/logo.png" alt="Logo" className="logo" />
      </div>
      <h1>Kalkulator Leasingu</h1>

      <label>Cena brutto (zł):</label>
      <input type="number" value={price} onChange={(e) => setPrice(Number(e.target.value))} />

      <label>Wkład własny: {initialPercent.toFixed(2)}%</label>
      <input type="number" value={initialAmount} onChange={(e) => setInitialAmount(Number(e.target.value))} />

      <label>Okres leasingu: {months} miesięcy</label>
      <input type="range" min="0" max="3" step="1" value={okresIdx}
        onChange={(e) => setOkresIdx(parseInt(e.target.value))} />

      <label>Wykup: {buyoutPercent.toFixed(2)}%</label>
      <input type="number" value={buyoutAmount} onChange={(e) => setBuyoutAmount(Number(e.target.value))} />
      {warning && <p className="warning">{warning}</p>}

      <div className="result">Rata brutto: {formatPLN(leaseInstallment)}</div>
      <div className="result">Suma kosztów leasingu: {formatPLN(totalCost)}</div>
      <div className="result">Całkowity koszt: {costPercent.toFixed(2)}%</div>
    </div>
  )
}
