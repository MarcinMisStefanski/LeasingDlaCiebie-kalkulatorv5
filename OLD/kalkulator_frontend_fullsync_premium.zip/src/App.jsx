
import React, { useState, useEffect } from 'react'

const RRSO = parseFloat(import.meta.env.VITE_RRSO) || 8.5
const okresy = [24, 35, 47, 59]

export default function App() {
  const [price, setPrice] = useState(220000)
  const [initialPercent, setInitialPercent] = useState(20)
  const [initialAmount, setInitialAmount] = useState(price * 0.2)
  const [okresIdx, setOkresIdx] = useState(1)
  const months = okresy[okresIdx]
  const [buyoutPercent, setBuyoutPercent] = useState(10)
  const [buyoutAmount, setBuyoutAmount] = useState(price * 0.1)
  const [warning, setWarning] = useState("")

  const monthlyRate = Math.pow(1 + RRSO / 100, 1 / 12) - 1

  useEffect(() => {
    setInitialAmount((price * initialPercent) / 100)
  }, [initialPercent, price])

  useEffect(() => {
    setInitialPercent(Math.round((initialAmount / price) * 100))
  }, [initialAmount])

  useEffect(() => {
    setBuyoutAmount((price * buyoutPercent) / 100)
  }, [buyoutPercent, price])

  useEffect(() => {
    setBuyoutPercent(Math.round((buyoutAmount / price) * 100))
  }, [buyoutAmount])

  const financedAmount = price - initialAmount - buyoutAmount
  const buyoutInterest = buyoutPercent > 1 ? buyoutAmount * monthlyRate * months : 0
  const totalFinanced = financedAmount + buyoutInterest

  const leaseInstallment = totalFinanced * (monthlyRate * Math.pow(1 + monthlyRate, months)) /
    (Math.pow(1 + monthlyRate, months) - 1)

  const totalCost = leaseInstallment * months + initialAmount + buyoutAmount
  const costPercent = (totalCost / price) * 100

  const validateBuyout = (mies, val) => {
    const rules = {
      24: [18, 60],
      35: [1, 50],
      47: [1, 40],
      59: [1, 30],
    }
    const [min, max] = rules[mies] || [1, 60]
    return val >= min && val <= max
  }

  const formatPLN = val => val.toLocaleString("pl-PL", { style: "currency", currency: "PLN" })

  const handleBuyoutChange = val => {
    const v = parseFloat(val)
    setBuyoutPercent(v)
    setWarning(validateBuyout(months, v) ? "" : "⚠️ Wartość wykupu poza zakresem")
  }

  return (
    <div className="container">
      <div className="header"><img src="/logo.png" alt="Logo" className="logo" /></div>
      <h1>Kalkulator Leasingu</h1>

      <label>Cena brutto: {formatPLN(price)}</label>
      <input type="range" min="100000" max="500000" step="1000" value={price}
        onChange={(e) => setPrice(Number(e.target.value))} />

      <label>Wkład własny: {initialPercent}% / {formatPLN(initialAmount)}</label>
      <input type="range" min="0" max="45" step="1" value={initialPercent}
        onChange={(e) => setInitialPercent(Number(e.target.value))} />
      <input type="number" value={initialAmount} onChange={(e) => setInitialAmount(Number(e.target.value))} />

      <label>Okres leasingu: {months} miesięcy</label>
      <input type="range" min="0" max="3" step="1" value={okresIdx}
        onChange={(e) => setOkresIdx(parseInt(e.target.value))} />

      <label>Wykup: {buyoutPercent}% / {formatPLN(buyoutAmount)}</label>
      <input type="range" min="1" max="60" step="1" value={buyoutPercent}
        onChange={(e) => handleBuyoutChange(e.target.value)} />
      <input type="number" value={buyoutAmount} onChange={(e) => setBuyoutAmount(Number(e.target.value))} />
      {warning && <p className="warning">{warning}</p>}

      <div className="result">💳 Rata brutto: {formatPLN(leaseInstallment)}</div>
      <div className="result">📦 Suma kosztów leasingu: {formatPLN(totalCost)}</div>
      <div className="result">📊 Całkowity koszt: {costPercent.toFixed(2)}%</div>
    </div>
  )
}
